# Lab 4: Follow the Gap

## YouTube video link
LEVINE BLOCKED:
https://youtu.be/ClHQn3qFPBE

LEVINE OBSTACLE:
https://youtu.be/ljGvVhNZZeI

REAL F1TENTH CAR ON TRACK:
https://youtube.com/shorts/1Jey521MJNQ?feature=share

REAL F1TENTH CAR WITH BASIC OBSTACLES:
https://youtube.com/shorts/ku2tMXONwcw?feature=share